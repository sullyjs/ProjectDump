import requests
import tkinter as tk

URL = ''

