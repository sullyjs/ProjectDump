 <!DOCTYPE html>
 
 <html>
 <head>
 
 <link rel="stylesheet" href="style.css">
 
 </head>
 
 <body>
	<h1>Submission Form</h1>
	<div class="loginblock">
	<!-- <form action="actionpage.php"> -->
	 <form action="home.html">
	  <p>Bookname</p><input type="text" name="bookname" required><br>
	  <p>Status Book</p>
	   <form>
		  MIA<input type="radio" name="boek" value="mia">
		  Uitgeleend<input type="radio" name="boek" value="uitgeleend">
		  Hier<input type="radio" name="boek" value="hier">
	   </form>
	  <p>Extra</p><input type="text" name="extra"><br><br>
	  <input type="submit" value="Submit" class="submbtn">
	</form> 
	</div>


	

	
</body>
</html>