<!DOCTYPE html>

<?php

session_start();

?>


<html>
<head>

<title>Library Management</title>
<link rel="stylesheet" href="style.css">

</head>

<body>




</body>

</html>